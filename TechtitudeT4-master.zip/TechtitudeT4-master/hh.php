<!DOCTYPE html>
<html>
        <head>
                <meta charset="utf-8">
                <title>CKEditor</title>
                <script src="https://cdn.ckeditor.com/ckeditor5/31.0.0/classic/ckeditor.js"></script>
        </head>
        <body>
              <?php
              echo $_POST['title'];
              echo $_POST['content'];
              echo $_POST['image'];
              echo $_POST['time'];
              
              ?>
        </body>
</html>