<?php

$con=  mysqli_connect("localhost", "root","", "tt4")or die(mysqli_error($con));